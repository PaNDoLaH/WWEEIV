<?php
value="<?php echo $name; ?>"